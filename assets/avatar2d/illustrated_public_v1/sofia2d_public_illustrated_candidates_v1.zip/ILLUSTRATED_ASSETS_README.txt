Sofía 2D PUBLIC Illustrated Candidate Pack v1
Contains 5 static public outfit portraits and 9 illustrated garment drafts plus a base character.
Install into the currently active LOCALAPPDATA/SofiaAdaLyra/Avatar2D/Public-V2 root.
Portraits are 320x400 transparent PNGs with SHA-256 manifests.
The separate garment illustrations are NOT already calibrated interchangeable rig layers.
This pack includes NO PRIVATE designs, and NEVER changes sofia.db.
Artwork is unreviewed and not yet source-exact or fully production accepted.
