Autumn Cyber public-only illustration and backdrop candidates. Static scene and source-locked full-outfit portrait; no private content, no animated clothing rig.
